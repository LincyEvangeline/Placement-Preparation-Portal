# Placement Preparation Portal

A beginner-friendly web application built with Python, Flask, HTML, CSS, and SQLite. It helps students practise aptitude, review beginner coding problems, and prepare for HR and technical interviews.

## Features

- Responsive home dashboard
- Multiple-choice aptitude quiz
- Automatic scoring and answer explanations
- SQLite database for saving quiz attempts
- Coding practice questions with sample solutions
- HR and technical interview preparation tips
- Recent quiz score history

## Technology

- Python 3.10 or newer
- Flask
- SQLite (included with Python)
- HTML and CSS

## Run locally

### 1. Download or clone this repository

```bash
git clone https://github.com/YOUR-USERNAME/placement-preparation-portal.git
cd placement-preparation-portal
```

If you downloaded the ZIP from GitHub, extract it and open the extracted folder in VS Code instead.

### 2. Create a virtual environment (recommended)

Windows:

```bash
py -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
python -m pip install -r requirements.txt
```

### 4. Start the website

Windows:

```bash
py app.py
```

Or:

```bash
python app.py
```

Open the local address printed in your terminal, usually http://127.0.0.1:5000.

The SQLite database is created automatically the first time you start the app. Quiz attempts are stored locally in `placement_portal.db`.

## Project structure

```text
placement-preparation-portal/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── aptitude.html
│   ├── result.html
│   ├── coding.html
│   ├── interviews.html
│   └── history.html
└── static/
    └── style.css
```

## Upload to GitHub

1. Sign in to GitHub and choose **New repository**.
2. Name it `placement-preparation-portal`.
3. Choose Public if you want recruiters to view it.
4. Create the repository. Do not add a README if you already have this README locally.
5. Open the project folder in VS Code.
6. Open Terminal → New Terminal and run:

```bash
git init
git add .
git commit -m "Initial placement preparation portal"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/placement-preparation-portal.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Run the `git remote add origin ...` command only once for this local folder. If Git is not installed, install Git first; if asked to sign in, follow GitHub's authentication prompt.

## Notes

- This is a learning/portfolio project, not a production recruitment platform.
- The quiz does not require a login. The name entered is stored with the score in the local database.
- Do not commit passwords, API keys, personal information, or your local database file.
- Coding solutions are displayed as examples; this project does not execute code submitted by users.

## Possible improvements

- Add student login and individual profiles.
- Add more quiz questions and difficulty levels.
- Add filtering by HR/technical interview category.
- Add charts for score progress.
- Deploy the app to a hosting service.
