from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from pathlib import Path

app = Flask(__name__)
DATABASE = Path(__file__).with_name("placement_portal.db")

QUESTIONS = [
    {
        "question": "A train travels 120 km in 2 hours. What is its average speed?",
        "options": ["40 km/h", "50 km/h", "60 km/h", "80 km/h"],
        "answer": "60 km/h",
        "explanation": "Average speed = distance / time = 120 / 2 = 60 km/h."
    },
    {
        "question": "What is 25% of 200?",
        "options": ["25", "40", "50", "75"],
        "answer": "50",
        "explanation": "25% means 25/100. So (25/100) × 200 = 50."
    },
    {
        "question": "Find the next number: 2, 4, 8, 16, ...",
        "options": ["18", "24", "30", "32"],
        "answer": "32",
        "explanation": "Each number is multiplied by 2. The next number is 16 × 2 = 32."
    },
    {
        "question": "If 5 pens cost ₹50, how much does one pen cost?",
        "options": ["₹5", "₹10", "₹15", "₹20"],
        "answer": "₹10",
        "explanation": "Cost of one pen = ₹50 / 5 = ₹10."
    },
    {
        "question": "Which number is the smallest?",
        "options": ["0.5", "0.05", "0.55", "0.505"],
        "answer": "0.05",
        "explanation": "0.05 is five hundredths, which is smaller than the other values."
    },
]

CODING_QUESTIONS = [
    {
        "title": "Reverse a string",
        "level": "Beginner",
        "description": "Write a Python program that reverses a string.",
        "example": 'Input: "hello"  →  Output: "olleh"',
        "solution": 'text = input("Enter a word: ")\nprint(text[::-1])'
    },
    {
        "title": "Check an even number",
        "level": "Beginner",
        "description": "Read an integer and print whether it is even or odd.",
        "example": "Input: 8  →  Output: Even",
        "solution": 'number = int(input("Enter a number: "))\nif number % 2 == 0:\n    print("Even")\nelse:\n    print("Odd")'
    },
    {
        "title": "Find the largest number",
        "level": "Beginner",
        "description": "Find the largest number in a list of numbers.",
        "example": "Input: [3, 9, 2]  →  Output: 9",
        "solution": "numbers = [3, 9, 2]\nprint(max(numbers))"
    },
]

INTERVIEW_QUESTIONS = [
    {
        "category": "HR",
        "question": "Tell me about yourself.",
        "tip": "Introduce your course, key skills, one project, and what you want to learn. Keep it around 45–60 seconds."
    },
    {
        "category": "HR",
        "question": "What are your strengths?",
        "tip": "Choose two genuine strengths and briefly explain how you use them in college or projects."
    },
    {
        "category": "Technical",
        "question": "What is the difference between a list and a tuple in Python?",
        "tip": "A list is mutable, so its contents can be changed. A tuple is immutable after it is created."
    },
    {
        "category": "Technical",
        "question": "What is a database?",
        "tip": "A database is an organized collection of data that can be stored, searched, updated, and managed."
    },
    {
        "category": "Technical",
        "question": "What is the purpose of GitHub?",
        "tip": "GitHub hosts Git repositories and helps people store code, track changes, and collaborate."
    },
]

def init_db():
    with sqlite3.connect(DATABASE) as connection:
        connection.execute("""
            CREATE TABLE IF NOT EXISTS quiz_results (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                score INTEGER NOT NULL,
                total INTEGER NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def index():
    with sqlite3.connect(DATABASE) as connection:
        total_attempts = connection.execute(
            "SELECT COUNT(*) FROM quiz_results"
        ).fetchone()[0]
    return render_template("index.html", total_attempts=total_attempts)

@app.route("/aptitude", methods=["GET", "POST"])
def aptitude():
    if request.method == "POST":
        student_name = request.form.get("student_name", "").strip() or "Student"
        score = 0
        review = []

        for index, question in enumerate(QUESTIONS):
            selected = request.form.get(f"question_{index}", "")
            correct = selected == question["answer"]
            if correct:
                score += 1
            review.append({
                "question": question["question"],
                "selected": selected or "Not answered",
                "answer": question["answer"],
                "correct": correct,
                "explanation": question["explanation"],
            })

        with sqlite3.connect(DATABASE) as connection:
            connection.execute(
                "INSERT INTO quiz_results (student_name, score, total) VALUES (?, ?, ?)",
                (student_name[:80], score, len(QUESTIONS))
            )

        return render_template(
            "result.html",
            student_name=student_name,
            score=score,
            total=len(QUESTIONS),
            review=review,
        )

    return render_template("aptitude.html", questions=QUESTIONS)

@app.route("/coding")
def coding():
    return render_template("coding.html", questions=CODING_QUESTIONS)

@app.route("/interviews")
def interviews():
    return render_template("interviews.html", questions=INTERVIEW_QUESTIONS)

@app.route("/history")
def history():
    with sqlite3.connect(DATABASE) as connection:
        connection.row_factory = sqlite3.Row
        results = connection.execute(
            "SELECT student_name, score, total, created_at "
            "FROM quiz_results ORDER BY id DESC LIMIT 20"
        ).fetchall()
    return render_template("history.html", results=results)

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
